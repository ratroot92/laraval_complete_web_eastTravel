           <!doctype html>
           <html class="no-js" lang="">
           <head>
           
           </head>
           <body>
           <div class="container-fluid">
           <div class="row">
                    <p>{{$inquiry->name}}</p>
                     <p>{{$inquiry->phone}}</p>
                      <p>{{$inquiry->adult}}</p>
                       <p>{{$inquiry->child}}</p>
                        <p>{{$inquiry->date}}</p>
                         <p>{{$inquiry->email}}</p>
                           <p>{{$inquiry->url}}</p>







           
                       
                        

          
           
           </div>
           
           </div>

            <div class="container-fluid">
           <div class="row">
                                                         NAME:  <p>{{$activity->name}}</p>
                                                         CITY: <p>{{$activity->city}}</p>
                                                         COUNTRY: <p>{{$activity->country}}</p>
                                                         DESCRIPTION :<p>{{$activity->desc}}</p>
                                                         ABOUT: <p>{{$activity->about}}</p>
                                                         DAY DETAIL: <p>{{$activity->day_detail}}</p>
                                                         DISCOUNT: <p>{{$activity->disc}}</p>
                                                         PRICE: <p>{{$activity->price}}</p>
                                                         CODE:   <p>{{$activity->code}}</p>
                                                         TERMS:   <p>{{$activity->terms}}</p>
                                                         PAYMENT POLICY:   <p>{{$activity->payment_policy}}</p>
                                                         CANCELLATION POLICY :   <p>{{$activity->cancellation_policy}}</p>
                                                         VISA INFO :     <p>{{$activity->visa_info}}</p>
                                                         NOTES:   <p>{{$activity->notes}}</p>                           
                                                         QUESTIONS:   <p>{{$activity->questions}}</p>
                                                         GROUP SIZE:  <p>{{$activity->grpsize}}</p>
                                                         TOUR CODE:  <p>{{$activity->tourcode}}</p>
                                                         DESTINATIONS: <p>{{$activity->destinations}}</p>
                                                         START LOCATION : <p>{{$activity->startloc}}</p>
                                                         TOUR STYLE:   <p>{{$activity->tourstyle}}</p>
                                                         TOUR LANGUAGE:  <p>{{$activity->tourlanguage}}</p>
                                                         AVALIBILITY DETAILS :  <p>{{$activity->avalibilitydetails}}</p>
                                                         TRANSPORT DETAILS : <p>{{$activity->tranportdetails}}</p>
                                                         ACCOMODATION DETAILS:    <p>{{$activity->accomodationdetails}}</p>
                                                         MEALS DETAILS:   <p>{{$activity->mealdetails}}</p>
                                                         TOUR STYLE:  <p>{{$activity->tourstyle}}</p>
                                                         STATUS:  <p>{{$activity->status}}</p>
                        
                           



           
                       
                        

          
           
           </div>
           
           </div>
           
           </body>
           </html>