
<div><img src="{{url('/theme/travel/images/logo.png')}}" style="height: 50%;width: 50%" alt=""></div>
<p><b>Get the account verified</b></p>
<p>click <a target="_blank" href="{{url('/auth/email/verify/')."/".$data['token'].'/'.$data['id']}}">
        here
        {{url('/auth/email/verify/')."/".$data['token'].'/'.$data['id']}}
    </a> </p>
<p>and Sign in again</p>
<i>Client Portal Nationaln.com</i>
