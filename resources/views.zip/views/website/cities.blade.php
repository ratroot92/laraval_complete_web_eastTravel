@extends('layouts.website')
@section('content')
<div class="row">
    <div class="col-md-12">
        <section>
<div class="rows tb-spaces pad-top-o pad-bot-redu">
<div class="container-fluid">
<!-- TITLE & DESCRIPTION -->
<div class="spe-title">
<h2>Popular <span>Cities</span> </h2>
<div class="title-line">
    <div class="tl-1"></div>
    <div class="tl-2"></div>
    <div class="tl-3"></div>
</div>
<p>We offer tours all over Europe find the perfect tours that best suits your needs.</p>
</div>
<!-- CITY -->
@foreach($cities as $item)
<div class="col-md-6">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[0]->banner}}" alt="" title="" {{--style="height: 100%;width: 100%"--}}>
        {{--<img src="{{url('/theme/travel')}}/images/listing/home.jpg" alt="">--}} </div>
        <div class="tour-mig-lc-con">
            <h5>{{$item[0]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[0]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[1]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[1]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[1]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[2]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[2]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[2]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[3]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[3]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[3]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[4]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[4]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[4]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
@endforeach
<div style="height:300px">

</div>
@foreach($cities as $item)
<div class="col-md-6 ">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[6]->banner}}" alt="" title="" {{--style="height: 100%;width: 100%"--}}>
        {{--<img src="{{url('/theme/travel')}}/images/listing/home.jpg" alt="">--}} </div>
        <div class="tour-mig-lc-con">
            <h5>{{$item[6]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[6]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[7]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[7]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[7]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[8]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[8]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[8]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[9]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[9]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[9]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[5]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[5]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[5]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
@endforeach
<div class="col-md-12 col-md-offset-2 mx-auto text-center" style="margin: 15px 0;">
<a class="link-btn" href="http://dvenza.com/"> Top Destinations</a>
</div>
</div>
</div>
</section>
    </div>
</div>

@endsection