@extends('layouts.website')
@section('content')
    <!--====== BANNER ==========-->

    <br><br><br><br>
    <div class="container jumbotron center-align">
<h1>{{ucfirst($type)}} Comming Soon</h1>
    </div>

@endsection
