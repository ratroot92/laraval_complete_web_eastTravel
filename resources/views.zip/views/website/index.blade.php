@extends('layouts.website')
@section('content')
{{-- <style>
table {
display: block;
overflow-x: auto;
white-space: nowrap;
}
</style>--}}
<style>
/*the container must be positioned relative:*/
.autocomplete {
position: relative;
display: inline-block;
}
input {
border: 1px solid transparent;
background-color: #f1f1f1;
padding: 10px;
font-size: 16px;
}
input[type=text] {
background-color: #f1f1f1;
width: 100%;
}
input[type=submit] {
background-color: DodgerBlue;
color: #fff;
cursor: pointer;
}
input.waves-button-input {
width: 100%;
}
.autocomplete-items {
position: absolute;
border: 1px solid #d4d4d4;
border-bottom: none;
border-top: none;
z-index: 99;
/*position the autocomplete items to be the same width as the container:*/
top: 100%;
left: 0;
right: 0;
}
.select-wrapper input.select-dropdown {
height: 45px;
}
.autocomplete-items div {
padding: 10px;
cursor: pointer;
background-color: #fff;
border-bottom: 1px solid #d4d4d4;
}
i.waves-effect.waves-light.tourz-sear-btn.waves-input-wrapper{
line-height: 24px;
}
/*when hovering an item:*/
.autocomplete-items div:hover {
background-color: #e9e9e9;
}
/*when navigating through the items using the arrow keys:*/
.autocomplete-active {
background-color: DodgerBlue !important;
color: #ffffff;
}
.list_3:hover{
font-size: 17px;
color: red;
}
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<div class="fb-customerchat"
 page_id="411933035571511">
</div>
<section>
    <div class="tourz-search">
        <div class="container">
            <div class="row">
                <div class="tourz-search-1">
                    <h1>Discover the Best of Central Europe!</h1>
                    <p>Make your choice and plan your trip at the best price in just a few minutes.</p>
                    <form class="row" action="{{url('search/result')}}">
                        
                        <div class="col-sm-6 col-lg-6" class="autocomplete" style="padding: 0px;margin: 0px">
                            <input type="search"  name="myCountry" id="select-search" class= " typeahead form-control " autocomplete="off" placeholder="Enter Destination (city or country)"  />
                            
                            
                            <div style="text-align: left;width:100%;background-color:white!important;position: absolute; z-index:99" id="search_div">
                                <h2 style="color: #253d52; padding-left: 15px">Popular <span style="color: #f4364f;font-size: 2rem;">Cities</span></h2>
                                <hr>
                                <div class="row ">
                                    <ul class="col-md-4 list-unstyled " style="margin:0px;padding:0px;padding-left:10px">
                                        <!--<span class="text-dark font-weight-bold btn "style="font-size:13px;font-weight:bold;color:black;;margin-top:10px!important; padding-bottom:10px;">Popular Cities </span>-->
                                        @foreach($cities as $city)
                                        <li  class="list_3"id ="{{$city[0]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[0]->country}} </li>
                                        <li class="list_3"id ="{{$city[1]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[1]->name}} </li>
                                        <li class="list_3"id ="{{$city[2]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[2]->name}} </li>
                                        <li class="list_3"id ="{{$city[3]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[3]->name}} </li>
                                        <li class="list_3"id ="{{$city[4]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[4]->name}} </li>
                                        <li class="list_3"id ="{{$city[5]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[5]->country}} </li>
                                        <li class="list_3"id ="{{$city[6]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[6]->name}} </li>
                                        <li class="list_3"id ="{{$city[7]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[7]->name}} </li>
                                        <li class="list_3"id ="{{$city[8]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[8]->name}} </li>
                                        <li class="list_3"id ="{{$city[9]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[9]->name}} </li>
                                        
                                        @endforeach
                                        
                                    </ul>
                                    <ul class="col-md-4 list-unstyled "style="margin:0px;padding:0px;">
                                        <!--<span class="text-dark font-weight-bold btn "style="font-size:13px;font-weight:bold;color:blue;;margin-top:10px!important; padding-bottom:10px;">Popular Countries </span>-->
                                        @foreach($cities as $city)
                                        <li class="list_3"id ="{{$city[0]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[0]->country}} </li>
                                        <li class="list_3"id ="{{$city[1]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[1]->country}} </li>
                                        <li class="list_3"id ="{{$city[2]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[2]->country}} </li>
                                        <li class="list_3"id ="{{$city[3]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[3]->country}} </li>
                                        <li class="list_3"id ="{{$city[4]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[4]->country}} </li>
                                        <li class="list_3"id ="{{$city[5]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[5]->country}} </li>
                                        <li class="list_3"id ="{{$city[6]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[6]->country}} </li>
                                        <li class="list_3"id ="{{$city[7]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[7]->country}} </li>
                                        <li class="list_3"id ="{{$city[8]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[8]->country}} </li>
                                        <li class="list_3"id ="{{$city[9]->country}}"style="font-weight:bold;margin-left:10px">  {{$city[9]->country}} </li>
                                        @endforeach
                                        
                                    </ul>
                                    <ul class="col-md-4 list-unstyled "style="margin:0px;padding:0px;">
                                        <!--<span class="text-dark font-weight-bold btn "style="font-size:13px;font-weight:bold;color:blue;;margin-top:10px!important; padding-bottom:10px;">Popular Cities </span>-->
                                        @foreach($cities as $city)
                                        <li  class="list_3"id ="{{$city[0]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[0]->name}} </li>
                                        <li class="list_3"id ="{{$city[1]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[1]->name}} </li>
                                        <li class="list_3"id ="{{$city[2]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[2]->name}} </li>
                                        <li class="list_3"id ="{{$city[3]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[3]->name}} </li>
                                        <li class="list_3"id ="{{$city[4]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[4]->name}} </li>
                                        <li class="list_3"id ="{{$city[5]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[5]->name}} </li>
                                        <li class="list_3"id ="{{$city[6]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[6]->name}} </li>
                                        <li class="list_3"id ="{{$city[7]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[7]->name}} </li>
                                        <li class="list_3"id ="{{$city[8]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[8]->name}} </li>
                                        <li class="list_3"id ="{{$city[9]->name}}" style="font-weight:bold;margin-left:10px">  {{$city[9]->name}} </li>
                                        
                                        @endforeach
                                        
                                    </ul>
                                    <div class="col-md-8 col-md-offset-2 mx-auto text-center" style="margin: 15px 0;">
                                        <a class="link-btn" href="/cities"> click to view more cities</a>
                                    </div>
                                </div>
                                
                            </div>
                            
                            
                            
                            
                            
                        </div>
                        <div class="col-sm-2 col-lg-2" class="autocomplete" style="padding: 0px;margin: 0px">
                            <div class="form-group" style="background-color:white">
                                
                                <select   id="options" name="options" style="width:100%;" required="required">
                                    <option>Select</option>
                                    <option value="1" style="font-size:12px!important;">Packages</option>
                                    <option value="2" style="font-size:12px!important">Day Tours</option>
                                    <option value="3" style="font-size:12px!important">Activities</option>
                                    <option value="4" style="font-size:12px!important">Cruises</option>
                                    <option value="5" style="font-size:12px!important">Transfers</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-lg-4" style="">
                            <input type="submit" value="search" class="waves-effect waves-light tourz-sear-btn" style="width: 100%;">
                        </div>
                    </form>
                    <div class="tourz-hom-ser">
                        <ul>
                            <li>
                                <a href="{{url('/packages/list')}}" class="waves-effect waves-light tourz-pop-ser-btn wow fadeInUp" data-wow-duration="0.5s"><img style="" src="{{url('theme/travel/')}}/images/icon/packages.png" alt="">Packages</a>
                            </li>
                            <li>
                                <a href="{{url('/daytours/list')}}" class="waves-effect waves-light tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1s"><img style="" src="{{url('theme/travel/')}}/images/icon/day-tour.png" alt=""> <i class="fas fa-plane-departure"></i>Day Tour</a>
                            </li>
                            <li>
                                <a href="{{url('/activities/list')}}"  class="waves-effect waves-light  tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1.5s"><img style="" src="{{url('theme/travel/')}}/images/icon/activity.png" alt=""> Activities</a>
                            </li>
                            <li>
                                <a href="{{url('/cruises/list')}}"  class="waves-effect waves-light tourz-pop-ser-btn wow fadeInUp" data-wow-duration="0.5s"><img style="" src="{{url('theme/travel/')}}/images/icon/cruiser.png" alt="">Cruises</a>
                            </li>
                            <li>
                                <a href="{{url('/transfers/list')}}" class="waves-effect waves-light tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1s"><img style="" src="{{url('theme/travel/')}}/images/icon/transfers.png" alt=""> <i class="fas fa-plane-departure"></i>Transfers</a>
                            </li>
                            <li>
                                <a href="{{url('/daytours/list')}}" class="waves-effect waves-light  tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1.5s"><img style="" src="{{url('theme/travel/')}}/images/icon/event.png" alt=""> Events</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--====== POPULAR TOUR PLACES ==========-->
<section>
    <div class="rows pad-bot-redu tb-spaces pt-5">
        <div class="container-fluid">
            <!-- TITLE & DESCRIPTION -->
            <div class="spe-title">
                <h2>Top <span>Tour Packages</span></h2>
                <div class="title-line">
                    <div class="tl-1"></div>
                    <div class="tl-2"></div>
                    <div class="tl-3"></div>
                </div>
                <p>We offer tour packages all over Europe find the perfect tour packages that best suits your needs.</p>
            </div>
            <!-- TOUR PLACE 1 -->
            <div class="carousel-wrap">
                <div class="owl-carousel">
                    @foreach(DB::table('packages')->orderBy('id','desc')->take(10)->get() as $key=>$s)
                    <div class="item">
                        <a href="{{url('packages/detail/'.$s->id)}}">
                            <div class="col-md-12 col-sm-12 col-xs-12 b_packages wow slideInUp p-t-10" data-wow-duration="0.5s">
                                <!-- OFFER BRAND -->
                                @if($s->disc!=0)<div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">{{$s->disc}}<br>OFF</span></div>
                                @else
                                <!--  <div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">No Discount</span></div> -->
                                @endif
                                <!--    <div class="band">-->
                                <!--    <div class="box">-->
                                <!--        <div class="ribbon"><span>{{$s->disc}}</span></div>-->
                                <!--    </div>-->
                                <!--    {{--<span class="w3-tag w3-yellow"></span>--}}-->
                                <!--    {{--  <img src="{{url('/theme/travel')}}/images/band.png" alt="" />--}}-->
                                <!--</div>-->
                                <!-- IMAGE -->
                                <div class="v_place_img" style="height: 200px">
                                    <img src="{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">
                                    <!--<img src="{{url('/').App\StoragePath::path()}}/storage/activities/{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">-->
                                </div>
                                <!-- TOUR TITLE & ICONS -->
                                <div class="b_pack rows"><!-- TOUR TITLE -->
                                <div class="col-lg-8 col-md-6">
                                    <h4>{{$s->name}}<span class="v_pl_name" style="color: black"></span></h4>
                                </div>
                                <!-- TOUR ICONS -->
                                <div class="col-lg-4 col-md-6 pack_icon">
                                    <a href="/activity/detail/{{$s->id}}" class="hot-page2-alp-quot-btn">Book Now</a>
                                    <!--<ul>-->
                                    <!--    <li>-->
                                    <!--        <a  href="{{url('packages/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/clock.png" alt="Date" title="Tour Timing" /> </a>-->
                                    <!--    </li>-->
                                    <!--    <li>-->
                                    <!--        <a  href="{{url('packages/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/info.png" alt="Details" title="View more details" /> </a>-->
                                    <!--    </li>-->
                                    <!--    <li>-->
                                    <!--        <a  href="{{url('packages/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/price.png" alt="Price" title="Price" /> </a>-->
                                    <!--    </li>-->
                                    <!--    <li>-->
                                    <!--        <a  href="{{url('packages/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/map.png" alt="Location" title="Location" /> </a>-->
                                    <!--    </li>-->
                                    <!--</ul>-->
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    <center>
    <div class="container">
        <a class ="link-btn" href="{{url('packages/list')}}"> See All Packages</a>
    </div>
    </center>
</div>
</section>
<section>
<div class="rows pad-bot-redu tb-spaces">
    <div class="container-fluid">
        <!-- TITLE & DESCRIPTION -->
        <div class="spe-title">
            <h2>Top <span>
            Day Tours</span></h2>
            <div class="title-line">
                <div class="tl-1"></div>
                <div class="tl-2"></div>
                <div class="tl-3"></div>
            </div>
            <p>We offer days tours all over Europe find the perfect days tours that best suits your needs.</p>
            {{--                    <p>World's leading tour and travels Booking website,Over 30,000 Events worldwide.</p>--}}
        </div>
        <!-- TOUR PLACE 1 -->
        <div class="carousel-wrap">
            <div class="owl-carousel">
                @foreach(DB::table('daytours')->orderBy('id','desc')->get() as $key=>$s)
                <div class="item">
                    <a href="{{url('daytour/detail/'.$s->id)}}">
                        <div class="col-md-12 col-sm-12 col-xs-12 b_packages wow slideInUp p-t-10" data-wow-duration="0.5s">
                            <!-- OFFER BRAND -->
                            @if($s->disc!=0)<div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">{{$s->disc}}<br>OFF</span></div>
                            @else
                            <!--  <div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">No Discount</span></div> -->
                            @endif
                            <!--    <div class="band">-->
                            <!--    <div class="box">-->
                            <!--        <div class="ribbon"><span>{{$s->disc}}</span></div>-->
                            <!--    </div>-->
                            <!--    {{--<span class="w3-tag w3-yellow"></span>--}}-->
                            <!--    {{--  <img src="{{url('/theme/travel')}}/images/band.png" alt="" />--}}-->
                            <!--</div>-->
                            <!-- IMAGE -->
                            <div class="v_place_img" style="height: 200px">
                                <img src="{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">
                                <!--<img src="{{url('/').App\StoragePath::path()}}/storage/activities/{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">-->
                            </div>
                            <!-- TOUR TITLE & ICONS -->
                            <div class="b_pack rows"><!-- TOUR TITLE -->
                            <div class="col-md-8 col-sm-8">
                                <h4>{{$s->name}}<span class="v_pl_name" style="color: black"></span></h4>
                            </div>
                            <!-- TOUR ICONS -->
                            <div class="col-md-4 col-sm-4 pack_icon">
                                <a href="/activity/detail/{{$s->id}}" class="hot-page2-alp-quot-btn">Book Now</a>
                                <!--<ul>-->
                                <!--    <li>-->
                                <!--        <a href="#"><img src="{{url('/theme/travel')}}/images/clock.png" alt="Date" title="Tour Timing" /> </a>-->
                                <!--    </li>-->
                                <!--    <li>-->
                                <!--        <a href="#"><img src="{{url('/theme/travel')}}/images/info.png" alt="Details" title="View more details" /> </a>-->
                                <!--    </li>-->
                                <!--    <li>-->
                                <!--        <a href="#"><img src="{{url('/theme/travel')}}/images/price.png" alt="Price" title="Price" /> </a>-->
                                <!--    </li>-->
                                <!--    <li>-->
                                <!--        <a href="#"><img src="{{url('/theme/travel')}}/images/map.png" alt="Location" title="Location" /> </a>-->
                                <!--    </li>-->
                                <!--</ul>-->
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>
</div>
<center>
<div class="container">
    <a class ="link-btn" href="{{url('daytours/list')}}"> See All Day Tours</a>
</div>
</center>
</div>
</section>
<section>
<div class="rows pad-bot-redu tb-spaces">
<div class="container-fluid">
    <!-- TITLE & DESCRIPTION -->
    <div class="spe-title">
        <h2>Top <span>
        Activities</span></h2>
        <div class="title-line">
            <div class="tl-1"></div>
            <div class="tl-2"></div>
            <div class="tl-3"></div>
        </div>
        <p>We offer activities all over Europe find the perfect activities that best suits your needs.</p>
        {{--                    <p>World's leading tour and travels Booking website,Over 30,000 Events worldwide.</p>--}}
    </div>
    <!-- TOUR PLACE 1 -->
    <div class="carousel-wrap">
        <div class="owl-carousel">
            @foreach(DB::table('activities')->orderBy('id','desc')->take(10)->get() as $key=>$s)
            <div class="item">
                <a href="{{url('activity/detail/'.$s->id)}}">
                    <div class="col-md-12 col-sm-12 col-xs-12 b_packages wow slideInUp p-t-10" data-wow-duration="0.5s">
                        <!-- OFFER BRAND -->
                        @if($s->disc!=0)<div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">{{$s->disc}}<br>OFF</span></div>
                        @else
                        <!--  <div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">No Discount</span></div> -->
                        @endif
                        <!--    <div class="band">-->
                        <!--    <div class="box">-->
                        <!--        <div class="ribbon"><span>{{$s->disc}}</span></div>-->
                        <!--    </div>-->
                        <!--    {{--<span class="w3-tag w3-yellow"></span>--}}-->
                        <!--    {{--  <img src="{{url('/theme/travel')}}/images/band.png" alt="" />--}}-->
                        <!--</div>-->
                        <!-- IMAGE -->
                        <div class="v_place_img" style="height: 200px">
                            <img src="{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">
                            <!--<img src="{{url('/').App\StoragePath::path()}}/storage/activities/{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">-->
                        </div>
                        <!-- TOUR TITLE & ICONS -->
                        <div class="b_pack rows"><!-- TOUR TITLE -->
                        <div class="col-md-8 col-sm-8">
                            <h4>{{$s->name}}<span class="v_pl_name" style="color: black"></span></h4>
                        </div>
                        <!-- TOUR ICONS -->
                        <div class="col-md-4 col-sm-4 pack_icon">
                            <a href="/activity/detail/{{$s->id}}" class="hot-page2-alp-quot-btn">Book Now</a>
                            <!--<ul>-->
                            <!--    <li>-->
                            <!--        <a href="{{url('activity/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/clock.png" alt="Date" title="Tour Timing" /> </a>-->
                            <!--    </li>-->
                            <!--    <li>-->
                            <!--        <a href="{{url('activity/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/info.png" alt="Details" title="View more details" /> </a>-->
                            <!--    </li>-->
                            <!--    <li>-->
                            <!--        <a href="{{url('activity/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/price.png" alt="Price" title="Price" /> </a>-->
                            <!--    </li>-->
                            <!--    <li>-->
                            <!--        <a href="{{url('activity/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/map.png" alt="Location" title="Location" /> </a>-->
                            <!--    </li>-->
                            <!--</ul>-->
                        </div>
                    </div>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>
</div>
<center>
<div class="container">
<a class ="link-btn" href="{{url('/activities')}}"> See All Activity</a>
</div>
</center>
</div>
</section>
<section>
<div class="rows pad-bot-redu tb-spaces">
<div class="container-fluid">
<!-- TITLE & DESCRIPTION -->
<div class="spe-title">
    <h2>Top <span>
    Cruises</span></h2>
    <div class="title-line">
        <div class="tl-1"></div>
        <div class="tl-2"></div>
        <div class="tl-3"></div>
    </div>
    <p>We cruises tours all over Europe find the perfect cruises that best suits your needs.</p>
    {{--                    <p>World's leading tour and travels Booking website,Over 30,000 Events worldwide.</p>--}}
</div>
<!-- TOUR PLACE 1 -->
<div class="carousel-wrap">
    <div class="owl-carousel">
        @foreach(DB::table('cruises')->orderBy('id','desc')->take(10)->get() as $key=>$s)
        <div class="item">
            <a href="{{url('cruise/detail/'.$s->id)}}">
                <div class="col-md-12 col-sm-12 col-xs-12 b_packages wow slideInUp p-t-10" data-wow-duration="0.5s">
                    <!-- OFFER BRAND -->
                    @if($s->disc!=0)<div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">{{$s->disc}}<br>OFF</span></div>
                    @else
                    <!--  <div class="band"> <img src="{{url('/theme/travel')}}/images/icon/ribbon.png" alt="" /><span class="disc-text">No Discount</span></div> -->
                    @endif
                    <!--    <div class="band">-->
                    <!--    <div class="box">-->
                    <!--        <div class="ribbon"><span>{{$s->disc}}</span></div>-->
                    <!--    </div>-->
                    <!--    {{--<span class="w3-tag w3-yellow"></span>--}}-->
                    <!--    {{--  <img src="{{url('/theme/travel')}}/images/band.png" alt="" />--}}-->
                    <!--</div>-->
                    <!-- IMAGE -->
                    <div class="v_place_img" style="height: 200px">
                        <img src="{{$s->banner}}" alt="Tour Booking" title="Tour Booking" style="height: 100%;width: 100%">
                    </div>
                    <!-- TOUR TITLE & ICONS -->
                    <div class="b_pack rows"><!-- TOUR TITLE -->
                    <div class="col-md-8 col-sm-8">
                        <h4>{{$s->name}}<span class="v_pl_name" style="color: black"></span></h4>
                    </div>
                    <!-- TOUR ICONS -->
                    <div class="col-md-4 col-sm-4 pack_icon">
                        <a href="/activity/detail/{{$s->id}}" class="hot-page2-alp-quot-btn">Book Now</a>
                        <!--<ul>-->
                        <!--    <li>-->
                        <!--        <a href="{{url('cruise/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/clock.png" alt="Date" title="Tour Timing" /> </a>-->
                        <!--    </li>-->
                        <!--    <li>-->
                        <!--        <a href="{{url('cruise/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/info.png" alt="Details" title="View more details" /> </a>-->
                        <!--    </li>-->
                        <!--    <li>-->
                        <!--        <a href="{{url('cruise/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/price.png" alt="Price" title="Price" /> </a>-->
                        <!--    </li>-->
                        <!--    <li>-->
                        <!--        <a href="{{url('cruise/detail/'.$s->id)}}"><img src="{{url('/theme/travel')}}/images/map.png" alt="Location" title="Location" /> </a>-->
                        <!--    </li>-->
                        <!--</ul>-->
                    </div>
                </div>
            </div>
        </a>
    </div>
    @endforeach
</div>
</div>
</div>
<center>
<div class="container">
<a class ="link-btn" href="{{url('cruises/list')}}"> See All Cruises</a>
</div>
</center>
</div>
</section>
<section>
<div class="rows tb-spaces pad-top-o pad-bot-redu">
<div class="container-fluid">
<!-- TITLE & DESCRIPTION -->
<div class="spe-title">
<h2>Popular <span>Cities</span> </h2>
<div class="title-line">
    <div class="tl-1"></div>
    <div class="tl-2"></div>
    <div class="tl-3"></div>
</div>
<p>We offer tours all over Europe find the perfect tours that best suits your needs.</p>
</div>
<!-- CITY -->
@foreach($cities as $item)
<div class="col-md-6">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[0]->banner}}" alt="" title="" {{--style="height: 100%;width: 100%"--}}>
        {{--<img src="{{url('/theme/travel')}}/images/listing/home.jpg" alt="">--}} </div>
        <div class="tour-mig-lc-con">
            <h5>{{$item[0]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[0]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[1]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[1]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[1]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[2]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[2]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[2]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[3]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[3]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[3]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[4]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[4]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[4]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
@endforeach
<div style="height:300px">

</div>
@foreach($cities as $item)
<div class="col-md-6 ">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[6]->banner}}" alt="" title="" {{--style="height: 100%;width: 100%"--}}>
        {{--<img src="{{url('/theme/travel')}}/images/listing/home.jpg" alt="">--}} </div>
        <div class="tour-mig-lc-con">
            <h5>{{$item[6]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[6]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[7]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[7]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[7]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[8]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[8]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[8]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            <img src="{{$item[9]->banner}}" alt="" title="" style="height: 150px;width: 255px">
            {{--<img src="{{url('/theme/travel')}}/images/listing/home3.jpg" alt="">--}}
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[9]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[9]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
<div class="col-md-3">
<a href="">
    <div class="tour-mig-like-com">
        <div class="tour-mig-lc-img">
            {{-- <img src="{{url('/theme/travel')}}/images/listing/home2.jpg" alt="">--}}
            <img src="{{$item[5]->banner}}" alt="" title="" style="height: 150px;width: 255px">
        </div>
        <div class="tour-mig-lc-con tour-mig-lc-con2">
            <h5>{{$item[5]->name}}</h5>
            <p><span>{{--12 Packages--}}</span> {{$item[5]->country}}{{--{{substr($item[0][0]->description,0,50)}}--}}{{--Starting from $2400--}}</p>
        </div>
    </div>
</a>
</div>
@endforeach
<div class="col-md-12 col-md-offset-2 mx-auto text-center" style="margin: 15px 0;">
<a class="link-btn" href="http://dvenza.com/"> Top Destinations</a>
</div>
</div>
</div>
</section>
<!--====== FOOTER 1 ==========-->
<div class="alert cookies" style="z-index: 10000; position: fixed; bottom: -10px">
<p style="font-size: 12px"><i class="fa fa-close" style="float: right;margin-right: 10px" onclick="$(this).parent().parent().toggle()"></i>WE AND OUR PARTNERS USE COOKIES ON THIS SITE TO IMPROVE OUR SERVICE, PERFORM ANALYTICS, PERSONALIZE ADVERTISING, MEASURE ADVERTISING PERFORMANCE, AND REMEMBER WEBSITE PREFERENCES.
BY USING THE SITE, YOU CONSENT TO THESE COOKIES. FOR MORE INFORMATION ON COOKIES INCLUDING HOW TO MANAGE YOUR CONSENT VISIT OUR <a href="{{url('/cookie/policy')}}">COOKIE POLICY</a>
</p>
</div>
@endsection
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" integrity="sha256-KM512VNnjElC30ehFwehXjx1YCHPiQkOPmqnrWtpccM=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
$('#search_div').hide();
$('#search_div').on('focusout', function(){
$('#search_div').fadeOut(2000);
})
$('#select-search').on('click', function(){
$('#search_div').show();
})
$('.list_3').on('click',function(){
var data_value=$(this).attr('id');
console.log("asd"+data_value)
$('#select-search').val('');
$('#select-search').val(data_value);
$('#search_div').fadeOut(1000);
})

});
</script>
<script>
$(document).mouseup(function(e)
{
var container = $("#search_div");
// if the target of the click isn't the container nor a descendant of the container
if (!container.is(e.target) && container.has(e.target).length === 0)
{
container.fadeOut(1000);
}
});
</script>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '205766477231808',
      xfbml      : true,
      version    : 'v5.0'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));

</script>
<script>
 
  FB.CustomerChat.show(shouldShowDialog: boolean);

</script>
