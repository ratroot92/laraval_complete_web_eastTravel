<!-- <br>
<div class=""style=" height: auto;padding-top: 20px!important;padding-bottom: 20px!important;
border-top:1px solid black; border-bottom: 1px solid black;">
	
	<center><label for=""  style="margin-left: 22px;color:#f4364f;">Additional Trip Details </label></center>


	    <div class="row">
	    <div class="col-md-6" >
		<label   style="margin-left: 22px;font-size:10px;margin-top:10px;">From Date </label>
		<input type="date" name="trip_from" id="trip_from" placeholder="flight form" class="form-control " style="height: 35px;" required="required">
	    </div>
	    <div class="col-md-6">
		<label   style="margin-left: 22px;font-size:10px;margin-top:10px;">To Date</label>
		<input type="date" name="trip_to" id="trip_to" class="form-control "style="height: 35px;"required="required">
	    </div>
	
	    </div>

	   

<div class="row">
	<label for="" style="margin-left: 30px;font-size:10px;margin-top: 10px;">Select Preffered Tour Type</label>

	<select name="trip_type" id="trip_type" class="form-control" style="width: 200px;margin-left:20px;border-radius: 0px;" required="required">
		<option value="">Select Tour Type</option>
		<option value="Private Tour (with Hotel Pickup) ">Private Tour (with Hotel Pickup) </option>
		<option value="Group  Tour (with Hotel Pickup)">Group  Tour (with Hotel Pickup) </option>
		<option value="Private Tour (without Hotel Pickup) ">Private Tour (without Hotel Pickup) </option>
		<option value="Group  Tour (without Hotel Pickup)">Group  Tour (without Hotel Pickup) </option>
	
	</select>
</div>
</div> 

asdasd