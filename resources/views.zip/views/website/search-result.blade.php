
@extends('layouts.website')
@section('content')


<style>
  nav{
    background-color: white;
    display: flex;
    justify-content: center;
    align-content: center;
    height: auto;
  }

</style>


<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">

      <div id="app">
        @include('flash-message')
        @yield('content')


      </div>        
    </div>    
  </div>
</div>

<section>
  <div class="rows inner_banner inner_banner_5">
    <div class="container">
      <h2><span>Book -</span> Your Favourite Packages Now!</h2>
      <ul>
        <li><a href="#inner-page-title">Home</a>
        </li>
        <li><i class="fa fa-angle-right" aria-hidden="true"></i> </li>
        <li><a href="#inner-page-title" class="bread-acti">packages</a>
        </li>
      </ul>
      <p>Book travel packages and enjoy your holidays with distinctive experience</p>
    </div>
  </div>
</section>


<div class="container" style="padding: 70px 0;">
  <div class="row">

    <div class="col-md-3 ">


    </div>
    <div class="col-md-12 " id="searchRendering">
      @if(count($packages) > 0)
      @foreach($packages as $key=>$item)
      <!-- <a href="/packages/detail/{{$item->id}}"> -->
       <div class="row" style="border:1px solid #e9ecef;background-color: white!important;margin-bottom: 10px;">

        <div class="col-md-3 img-thumbnail  " style="padding:0px; margin:0px;border-radius:0px;">
         <img src="{{$item->banner}}" width="100%" height="150px"  alt="" style="padding:0px; margin:0px;"> 
       </div>
       <div class="col-md-6" >
        <div class="trav-list-bod">
          <a href="/packages/detail/{{$item->id}}"><h3 style="color:#f4364f;font-family: 'Quicksand', sans-serif;
          font-weight: 700;">{{$item->name}}</h3></a>
          <p>{{substr($item->desc,0,150)}}....</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="hot-page2-alp-ri-p3 tour-alp-ri-p3">
          <div class="hot-page2-alp-r-hot-page-rat pull">{{$item->disc}}%Off</div> <span class="hot-list-p3-1">From</span> <span class="hot-list-p3-2">€{{$item->price}}</span><span class="hot-list-p3-4">
            <a href="/packages/detail/{{$item->id}}" class="hot-page2-alp-quot-btn">Book Now</a>

          </span> </div>
        </div>
        <div>
          <div class="trav-ami">
           <h4>Detail and Includes</h4>
           <ul>



            @if(count($icons)>1 )

            @foreach($icons as $icon )
            @if($icon->name=='sightseeing' && $icon->fkey==$item->id)
            <li href="/packages/detail/{{$item->id}}"><img src="{{asset('public/images/icon/a14.png')}}" alt=""> <span>Sightseeing</span></li>
            @else
            @endif
            @endforeach

            @foreach($icons as $icon )
            @if($icon->name=='hotel' && $icon->fkey==$item->id)
            <li href="/packages/detail/{{$item->id}}"><img src="{{asset('public/images/icon/a15.png')}}" alt=""> <span>Hotel</span></li>
            @else
            @endif
            @endforeach

            @foreach($icons as $icon)
            @if($icon->name=='transfer' && $icon->fkey==$item->id)
            <li href="/packages/detail/{{$item->id}}"><img src="{{asset('public/images/icon/a16.png')}}"alt=""> <span>Transfer</span></li>
            @else
            @endif
            @endforeach

            @foreach($icons as $icon)
            @if($icon->name=='days' && $icon->fkey==$item->id)
            <li href="/packages/detail/{{$item->id}}"><img src="{{asset('public/images/icon/a18.png')}}"alt=""> <span>{{$item->duration}}</span></li>
            @else
            @endif
            @endforeach

            @foreach($icons as $icon)
            @if($icon->name=='multiple_cities' && $icon->fkey==$item->id)
            <li href="/packages/detail/{{$item->id}}"><img src="{{asset('public/images/icon/a19.png')}}" alt="">
             <span style="font-size: 11px">  Multiple Cities</span>
             @else
             @endif
             @endforeach






             @foreach($icons as $icon )
             @if($icon->name=='breakfast' && $icon->fkey==$item->id)
             <li href="/activity/detail/{{$item->id}}"><img src="https://image.flaticon.com/icons/png/512/84/84072.png" alt=""> <span>Breakfast</span></li>
             @else
             @endif
             @endforeach




             @foreach($icons as $icon )
             @if($icon->name=='breakfast_halfboard' && $icon->fkey==$item->id)
             <li href="/activity/detail/{{$item->id}}"><img src="https://image.flaticon.com/icons/png/512/84/84072.png" alt=""> <span>Half_board</span></li>
             @else
             @endif
             @endforeach





             @foreach($icons as $icon)
             @if($icon->name=='breakfast_full_board' && $icon->fkey==$item->id)
             <li href="/activity/detail/{{$item->id}}"><img src="https://image.flaticon.com/icons/png/512/84/84072.png"alt=""> <span>Full_board</span></li>
             @else
             @endif
             @endforeach




             @foreach($icons as $icon)
             @if($icon->name=='transfer_icon' && $icon->fkey==$item->id)
             <li href="/activity/detail/{{$item->id}}"><img src="http://simpleicon.com/wp-content/uploads/car.png"alt=""> <span>Transfer</span></li>
             @else
             @endif
             @endforeach





             @foreach($icons as $icon)
             @if($icon->name=='cruiser_icon' && $icon->fkey==$item->id)
             <li href="/activity/detail/{{$item->id}}"><img src="https://www.pngrepo.com/png/193576/170/cruiser-war.png" alt="">
               <span style="font-size: 11px">  Cruiser</span>
               @else
               @endif
               @endforeach



               @foreach($icons as $icon)
               @if($icon->name=='flight_icon' && $icon->fkey==$item->id)
               <li href="/activity/detail/{{$item->id}}"><img src="http://cdn.onlinewebfonts.com/svg/img_528940.png"alt=""> <span>Flight</span></li>
               @else
               @endif
               @endforeach





               @foreach($icons as $icon)
               @if($icon->name=='activity_icon' && $icon->fkey==$item->id)
               <li href="/activity/detail/{{$item->id}}"><img src="https://cdn1.iconfinder.com/data/icons/recreational-activities-1/64/16-512.png" alt="">
                 <span style="font-size: 11px">  Activity</span>
                 @else
                 @endif
                 @endforeach



               </li>
             </ul>
             @else
             @endif


             {{-- <span>@if(count($cities)>1)
              Multiple Cities
              @else
              @foreach($cities as $item)
              {{$item->name}}
              @endforeach
            @endif</span> --}}
          </div>  
        </div>
      </div>
    <!-- </a> -->
    @endforeach


  </div>{{-- end  col-md-8 --}}       
</div>    
</div>



<div class="container-fluid">
  <div class="row">
    <div  class="col-md-12">
      {{$packages->links()}}   
    </div>       
  </div>    
</div>

@else
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 alert alert-warning">
      <p>No results search</p>
    </div>
  </div>
</div>
@endif
</li>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
@endsection
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>   
